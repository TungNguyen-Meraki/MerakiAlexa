# Your Meraki admin login's corresponding API key
# Add yourself as a full org admin to the Demo API Lab org @
# https://n27.meraki.com/o/Z8Zbqb/manage/organization/admins
# "Become user" if needed to add yourself as an admin
# Ensure this key has access to both the Demo API Lab org as well as your kit org
api_key = '8fa56d92e3c052fb8443b2130b15a56cbcbc65b1'

# Do NOT modify, this is the Alexa API Lab org ID for https://n27.meraki.com/o/Z8Zbqb/manage/organization/
### DO NOT MODIFY
lab_org = '694549'
### DO NOT MODIFY

# Your city, to be added onto the map for the provision.py script
kit_city = 'Boston, MA'

# Your own lab kit org, for local client device demo
kit_org = '340887'

# Network ID within that org, where the Meraki device lives
kit_net = 'L_568579452955527935'

# Serial number of a device in network, which your client device is connected
kit_sn = 'Q2RN-EDHU-PLL2'

# How far back in days (decimals OK, so fraction of a day if needed) should we search for your client device & usage?
# 0.5 for 12 hours, 0.25 for 6 hours, 0.125 for 3 hours, 0.0834 for 2 hours (minimum)
time_days = 0.25

# What name should we look for in client devices? (you'll have to rename clients in Dashboard manually)
# Make sure this matches in Dashboard exactly (must CONTAIN the following string)
client_name = 'Shay'

# What group policy should we look for to assign to those client devices with client_name?
# Make sure this matches in Dashboard exactly (must EQUAL the following string)
group_policy = 'Block streaming video'



# Optional section: SM network, device name, and profile settings to remove then apply
# Certain profile settings such as wallpaper only work for DEP/supervised devices
sm_org = 'ORG_ID'
sm_net = 'NET_ID'
sm_device = 'Shay\'s iPad'
sm_old_profile = 'WP-Cat'
sm_new_profile = 'WP-Alpaca'